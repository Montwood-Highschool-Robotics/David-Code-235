package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
abstract class
Hope_and_Pray extends LinearOpMode {

}